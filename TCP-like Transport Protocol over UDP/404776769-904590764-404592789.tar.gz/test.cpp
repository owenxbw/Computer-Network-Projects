#include<iostream>
#include"TCPHeader.h"
using namespace std;

int main()
{
  TCPHeader aaa;
  aaa.setSeqNumber(16788);
  aaa.setAckNumber(11);
  aaa.setWinSize(1024);
  aaa.setFlags(5);
  char str[8] = {0};
  aaa.generate(str);//now str contains the header

  TCPHeader bbb;
  bbb.consume(str);//parse str which contains a header
  unsigned short seqnum = bbb.seqNum();
  unsigned short acknum = bbb.ackNum();
  unsigned short winsize = bbb.winSize();
  unsigned short flag = bbb.flags();
  cout << "Sequence Number is: " << seqnum << endl;
  cout << "Acknowledge Number is: " << acknum << endl;
  cout << "Window Size is: " << winsize << endl;
  cout << "Flags is: " << flag << endl;
  cout << "FIN is: " << bbb.FIN() << endl;
  cout << "SYN is: " << bbb.SYN() << endl;
  cout << "RST is: " << bbb.RST() << endl;

  return 0;
}
